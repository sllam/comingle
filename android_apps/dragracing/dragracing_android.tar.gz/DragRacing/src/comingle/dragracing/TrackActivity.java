package comingle.dragracing;

import dragracing.Dragracing;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import comingle.actuation.ActuatorAction;
import comingle.dragracing.R;
import comingle.facts.SerializedFact;
import comingle.nodes.SendListener;
import comingle.tuple.*;

import android.support.v7.app.ActionBarActivity;
import android.net.wifi.p2p.WifiP2pManager;
import android.net.wifi.p2p.WifiP2pManager.Channel;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.IntentFilter;
import android.content.DialogInterface.OnClickListener;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import sllam.extras.datapipe.*;
import sllam.extras.p2pdirectory.*;

public class TrackActivity extends ActionBarActivity {

	/** Called when the activity is first created. */
	/*
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(new MyView(this));
	} */

	DataPipe<String> datapipe;
	
	class Car {
		private Rect sprite;
		private Paint paint;
		private boolean throttle;
		private int owner;
		private int impulse_time;
		
		public Car(int owner) {
			this.owner = owner;
			paint = new Paint();
			paint.setColor(CAR_COLORS[owner]);
			throttle = false;
			int left   = 0;
	      	int right  = 0 + TRACK_WIDTH;
	      	int top    = TOP_MARGIN + TRACK_WIDTH*owner + 2; 
	      	int bottom = TOP_MARGIN + TRACK_WIDTH*(owner+1) - 2;
	      	sprite = new Rect(left, top, right, bottom);			
	      	impulse_time = 0;
		}
	
		
		public void setSprite(Rect new_sprite) {
			sprite = new_sprite;
		}
		
		public Rect getSprite() {
			return sprite;
		}
		
		public Paint getPaint() {
			return paint;
		}
		
		public boolean getThrottle() {
			return throttle;
		}
		
		public int getIdx() { return owner; }
		
		public int getOwner() {
			return owner;
		}
		
		public void toggle(boolean tog) {
			throttle = tog;
		}
		
		public void move(int new_pos) {
	    	int left   = new_pos;
	   	   	int right  = new_pos + TRACK_WIDTH;
	   	   	int top    = TOP_MARGIN + TRACK_WIDTH*owner + 2; 
	   	   	int bottom = TOP_MARGIN + TRACK_WIDTH*(owner+1) - 2;
	   	   	sprite = new Rect(left, top, right, bottom);
		}
		
		public void impulse() {
			impulse_time = (int) System.currentTimeMillis();
		}
		
		public boolean checkImpulse(int refresh_time) {
			if(impulse_time == 0) { return false; }
			return refresh_time - impulse_time <= IMPULSE_LENGTH;
		}
		
	}
	
	private static final int DATA_PORT = 8819;
	
	private static final int LEGEND_MARGIN = 50;
	
	private static final int TOP_MARGIN = 300;
	private static final int TRACK_WIDTH = 30;
	private static final int TRACK_LENGTH = 800;
	private static final int TRACK_CENTER = 500;
	private static final int CAR_DISPLACEMENT = 10;
	
	private static final int FPS = 32;
	private static final int FPS_RATE = 1000 / FPS;
	
	private static final int IMPULSE_LENGTH = 30;
	
	private static final int BG_COLOR = Color.WHITE;
	private static final int[] CAR_COLORS = { Color.RED, Color.BLUE, Color.GREEN
		                                    , Color.YELLOW, Color.MAGENTA, Color.CYAN
		                                    , Color.BLACK, Color.LTGRAY };
	
	private static final String[] INTERVAL_MARKERS = { "A", "B", "C", "D", "E", "F", "G", "H" };
	
	private Canvas track_canvas;
	private LinkedList<Car> cars;
	private LinearLayout track;
	
	boolean timerStarted = false;
	boolean link_inited = false;
	Timer timer;
	TimerTask refreshTrackTask;
	
	int time_pressed;
	int time_released;
	
	int prev_refresh_time;
	
	boolean brakes = true;
	
	private final IntentFilter intentFilter = new IntentFilter();

	private Channel mChannel;
	private WifiP2pManager mManager;
	private WifiP2pBroadcastReceiver mReceiver = null;	
	
	private WifiP2pDir p2p_dir = null;
	private DataPipe<SerializedFact> data_pipe;
	private int wifip2p_refresh_counter = 0;
	private int my_loc;
	
	private Dragracing rm;
	private boolean rm_inited = false;
	private boolean rm_restarted = false;
	private boolean no_wifi_refresh = false;

	private Menu options_menu;
	
	public void recordTimePressed() {
		time_pressed = (int) System.currentTimeMillis();
	}

	public void reportTimeReleased() {
		time_released = (int) System.currentTimeMillis();
		Toast.makeText(this, String.format("Duration: %s", time_released - time_pressed)
				      ,Toast.LENGTH_SHORT).show();
	}
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
    	setContentView(R.layout.activity_track);
    	Bitmap bg = Bitmap.createBitmap(TRACK_LENGTH, 800, Bitmap.Config.ARGB_8888);
    	track_canvas = new Canvas(bg); 
       
		// Initialization stuff for P2P WiFi
		intentFilter.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION);
		// Indicates a change in the list of available peers.
		intentFilter.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION);
		// Indicates the state of Wi-Fi P2P connectivity has changed.
		intentFilter.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION);
		// Indicates this device's details have changed.
		intentFilter.addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION);

		mManager = (WifiP2pManager) getSystemService(Context.WIFI_P2P_SERVICE);
		mChannel = mManager.initialize(this, getMainLooper(), null);
		initP2pDir();
		initDataPipe();
		
    	cars = new LinkedList<Car>();
		
		initBanner(false);
		
		track = (LinearLayout) findViewById(R.id.track);
		track.setBackground(new BitmapDrawable(getResources(), bg));   
       
		final TrackActivity self = this;
       
		refreshTrackTask = new TimerTask() {
    	   @Override
    	   public void run() {
    		   self.refreshTrack();
    	   }
		};
		
       
		track.setOnTouchListener(new View.OnTouchListener() {
		
    	   @Override
    	   public boolean onTouch(View v, MotionEvent event) {
    		   // TODO Auto-generated method stub
    		   switch(event.getAction()) {
    		   		case MotionEvent.ACTION_DOWN: 
    		   			if (!self.breaksOn()) {
    		   			  rm.add_sendtap(self.getLoc());
    		   			}
    		   			// self.recordTimePressed();
    		   			return true;
    		   		case MotionEvent.ACTION_UP:
    		   			// rm.add_sendtoggle(self.getLoc(), false);
    		   			// self.reportTimeReleased();
    		   			return true;
    		   }
    		   return true;
    	   }
       });
    }
    
    public int getLoc() { return my_loc; }
    
    @Override
    protected void onResume() {
    	super.onResume();
    	startTimerIfNeeded();
    	registerReceiverIfNeeded();
    }
    
    @Override
    protected void onPause() {
    	super.onPause();
    	stopTimerIfNeeded();
    	unregisterReceiverIfNeeded();
    }
    
    @Override
    protected void onDestroy() {
    	super.onDestroy();
    	p2p_dir.close();
    }
    
	public void registerReceiverIfNeeded() {
		if (mReceiver == null) {
			mReceiver = new WifiP2pBroadcastReceiver(mManager, mChannel, this, p2p_dir);
			registerReceiver(mReceiver, intentFilter);			
		}
	}
	
	public void unregisterReceiverIfNeeded() {
		if (mReceiver != null) {
			unregisterReceiver(mReceiver);
			mReceiver = null;
		}
	}

    
    public void startTimerIfNeeded() {
    	if (!timerStarted) {
    		prev_refresh_time = (int) System.currentTimeMillis();
    		timer = new Timer();
    		timer.schedule(refreshTrackTask, 0, FPS_RATE);
    		timerStarted = true;
    	}
    }
    
    public void stopTimerIfNeeded() {
    	if (timerStarted) {
    		timer.cancel();
    		timer.purge();
    		timer = null;
    		timerStarted = false;
    	}
    }
    	
	
    public int getPrevRefreshTime() {
    	return prev_refresh_time;
    }
    
    public void setPrevRefreshTime(int new_refresh_time) {
    	prev_refresh_time = new_refresh_time;
    }

    public void renderTrack(LinkedList<Integer> locs) {
		no_wifi_refresh = true;
    	initTrack(locs.size());
    	initMarkers(locs);
    }
   
    private void initTrack(int num_of_lanes) {
        Paint paint = new Paint();
        paint.setColor(Color.parseColor("#CD5C5C"));
        for (int i=0; i<=num_of_lanes; i++) {
     	   float top_track_y = TOP_MARGIN + TRACK_WIDTH*i;
     	   // float bot_track_y = TOP_MARGIN + TRACK_CENTER + TRACK_WIDTH*i;
           track_canvas.drawLine(0, top_track_y, 800, top_track_y, paint);   
           // track_canvas.drawLine(0, bot_track_y, 800, bot_track_y, paint);
        }   		
    }  
    
    private void initMarkers(LinkedList<Integer> locs) {
       	Paint text_paint = new Paint();
    	text_paint.setColor(Color.BLACK);
    	text_paint.setTextSize(20);
    	
    	String prev = "Start";
    	String next = "End";
    	for(int x=0; x<locs.size(); x++) {
    		if (locs.get(x) == this.my_loc) {
    			if(x > 0) { prev = String.format("<< %s", INTERVAL_MARKERS[x-1]); }
    			if(x < locs.size()-1) { next = String.format("%s >>", INTERVAL_MARKERS[x]); }
    			break;
    		}
    	}
		track_canvas.drawText(prev, 20, TOP_MARGIN-20, text_paint);
		track_canvas.drawText(next, 800-50, TOP_MARGIN-20, text_paint);
    	
		/*
		if (my_loc == locs.get(0)) {
			for(int loc: locs) {
				this.addCar(loc);
			}
		} */
    }
    
    public void moveCar(Car car, int time_prev, int time_curr) { 
    	Paint bg_paint = new Paint();
    	bg_paint.setColor(BG_COLOR);
    	track_canvas.drawRect(car.getSprite(), bg_paint);
    	int new_pos = RacerLib.newPos(car.getSprite().left, time_prev, time_curr);
    	
    	if (new_pos < TRACK_LENGTH) {
    		car.move(new_pos);    	
    		track_canvas.drawRect(car.getSprite(), car.getPaint());
    	} else {
    		removeCar(car.getOwner());
    		rm.add_checkexit(my_loc, car.getOwner());
    	}
    }

    public void initRewrite() {
    	if (rm_inited) { return; }
    	rm = new Dragracing();
   
    	final TrackActivity self = this;
    	
    	ActuatorAction<LinkedList<Integer>> renderTrackAction = new ActuatorAction<LinkedList<Integer>>() {
			@Override
			public void doAction(LinkedList<Integer> locs) {
				self.renderTrack(locs);
			}    		
    	};
    	rm.setActuator(Dragracing.Actuations.rendertrack, renderTrackAction);
    	
    	ActuatorAction<Unit> releaseAction = new ActuatorAction<Unit>() {
			@Override
			public void doAction(Unit arg0) {
				self.countDown(0);
			}
    	};
    	rm.setActuator(Dragracing.Actuations.release, releaseAction);
    	
    	ActuatorAction<Integer> recvTapAction = new ActuatorAction<Integer>() {
			@Override
			public void doAction(Integer car_idx) {
				self.toggleCar(car_idx, true);
			}
    	};
    	rm.setActuator(Dragracing.Actuations.recvtap, recvTapAction);
    	
    	ActuatorAction<Integer> hasAction = new ActuatorAction<Integer>() {
			@Override
			public void doAction(Integer car_idx) {
				self.addCar(car_idx, true);
			}
    	};
    	rm.setActuator(Dragracing.Actuations.has, hasAction);
    	
    	ActuatorAction<Integer> decWinnerAction = new ActuatorAction<Integer>() {
			@Override
			public void doAction(Integer winner) {
					self.declareWinner(winner);
			}
    	};
    	rm.setActuator(Dragracing.Actuations.decwinner, decWinnerAction);
    
		// Specifying message passing instance and setup P2P configurations
		SendListener send_listener = new SendListener() {
			@Override
			public void performSendAction(final String ip_address, final List<SerializedFact> facts) {
				self.runOnUiThread(
					new Runnable() {
						@Override
						public void run() {
							self.sendData(ip_address, facts);
						}
					});
			}
		};
		HashMap<Integer,String> loc_map = p2p_dir.retrieveLocIPMap();
		WifiP2pEntry local_entry = p2p_dir.getLocalEntry();
		rm.setupNeighborhood(local_entry.location, local_entry.ip_address
				            ,send_listener, loc_map);	
		
		rm.init();
		rm_inited = true;
		rm.start();
		
		if(rm_restarted && my_loc == 0) {
			beginRace();
		}
		
		rm_restarted = true;
    }
    
    public void refreshTrack() {
    	final TrackActivity self = this;
    	this.runOnUiThread(new Runnable() {
    		@Override
    		public void run() {
    			int curr_refresh_time = (int) System.currentTimeMillis();
    			int prev_refresh_time = self.getPrevRefreshTime();
    	    	for(int i=0; i<cars.size(); i++) {
    				   Car car = cars.get(i);
    				   if(car.checkImpulse(curr_refresh_time)) { // car.getThrottle()) {
    					   self.moveCar(car, prev_refresh_time, curr_refresh_time);
    				   }
    			}
    	    	if (!no_wifi_refresh) { self.refreshWifiDir(); }
    	    	self.setPrevRefreshTime(curr_refresh_time);
    			track.invalidate();
    		}
    	});
    }
    
    public void initBanner(boolean with_wifi_data) {
    	
    	Paint text_paint = new Paint();
    	text_paint.setColor(Color.BLACK);
    	text_paint.setTextSize(20);
    	
    	track_canvas.drawText("YOU:", 20, LEGEND_MARGIN-20, text_paint);
    	track_canvas.drawText("THE BAD & UGLY:", 520, LEGEND_MARGIN-20, text_paint);
    	
    	if (with_wifi_data) {
    		placeCarAvailable( my_loc, 0, 0 );
    		List<WifiP2pEntry> group_members = this.p2p_dir.getDirectory();
        	int opp_count = 0;
        	for (WifiP2pEntry entry: group_members) {
        		String loc = entry.getLocation();
        		placeCarAvailable( Integer.parseInt(loc), 500, opp_count );
        		opp_count++;
        	}
    	} 
    	
    }
    
    public void restartGame() {
    	
    	setBrakes(true);
    	
    	rm.stop_rewrite();
    	
    	link_inited = false;
    	rm_inited = false;
    	
    	cars = new LinkedList<Car>();
    	
    	track_canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
    	
		initBanner(true);
		
		initRewrite();
		
		// beginRace();
		
    }
    
    public void refreshWifiDir() {
    	this.wifip2p_refresh_counter ++;
    	if (this.wifip2p_refresh_counter < (FPS*2)) { return; }
    	this.wifip2p_refresh_counter = 0;
    	
    	p2p_dir.updateMacIPMap();
    	WifiP2pEntry local_entry   = this.p2p_dir.getLocalEntry();
    	List<WifiP2pEntry> group_members = this.p2p_dir.getDirectory();
    	if(local_entry != null) {
    		String loc = local_entry.getLocation();
    		my_loc = Integer.parseInt(loc);
    		placeCarAvailable( my_loc, 0, 0 );
    		if (my_loc == 0) {
    			this.setMenuItemVisibility(R.id.action_start, true);
    		}
    	}
    	int opp_count = 0;
    	for (WifiP2pEntry entry: group_members) {
    		String loc = entry.getLocation();
    		placeCarAvailable( Integer.parseInt(loc), 500, opp_count );
    		opp_count++;
    	}
    	if (!rm_inited) {
    		initRewrite();
    	} else {
    		rm.addNeighbors(p2p_dir.retrieveLocIPMap(), false);
    	}
    }
    
    public void placeCarAvailable(int car_idx, int left_margin, int pos_idx) {
    	if (car_idx < 0 || car_idx >= CAR_COLORS.length) { return; }
    	
    	Paint car_paint = new Paint();
    	car_paint.setColor(CAR_COLORS[car_idx]);
    	
    	int left   = left_margin + TRACK_WIDTH*pos_idx + 20;
   	   	int right  = left_margin + TRACK_WIDTH*(pos_idx+1) + 20;
   	   	int top    = LEGEND_MARGIN + 2; 
   	   	int bottom = LEGEND_MARGIN + TRACK_WIDTH - 2;
   	   	Rect sprite = new Rect(left, top, right, bottom);
    	
   	   	track_canvas.drawRect(sprite, car_paint);
   	   	
    }
    
    public void declareWinner(int car_idx) {
    	
    	String msg;
    	if (my_loc == car_idx) { 
    		msg = "YOU WIN!";
    	} else {
    		msg = "YOU LOSE!";
    	}
    	restartGame();
    	postAlert("Game Over", msg);
    }
    
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.track, menu);
		options_menu = menu;
		return true;
	}

	public void beginRace() {
		LinkedList<Integer> locs = new LinkedList<Integer>();
		locs.addLast(0);
		List<WifiP2pEntry> members = p2p_dir.getDirectory();
		for (int x=1; x<=members.size(); x++) {
			locs.addLast(x);
		}
		rm.add_initrace(my_loc, locs);
		this.setMenuItemVisibility(R.id.action_go, true);
		this.setMenuItemVisibility(R.id.action_start, false);
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		switch (id) {
			case R.id.action_settings: return true;
			case R.id.action_start:
				if (this.rm_inited && my_loc == 0) {
					// rm.add_beginrace(my_loc, 0);
					beginRace();
				}
				return true;
			case R.id.action_go:
				if (this.rm_inited && my_loc == 0) {
					rm.add_go(my_loc);
				}
				return true;
			case R.id.action_restart:
				this.restartGame();
				return true;
		} 
		return super.onOptionsItemSelected(item);
	}
	
	public void setMenuItemVisibility(int id, boolean visible) {
		if (options_menu == null) { return; }
		MenuItem item = options_menu.findItem(id);
		if (item != null) {
			item.setVisible(visible);
		}
	}
	
	protected void initP2pDir() {
		if (p2p_dir != null) { return; }
		p2p_dir = new WifiP2pDir(this);
	}
	
	protected void initDataPipe() {
		if(data_pipe != null) { 
			data_pipe.close();
			data_pipe = null;
		}

		final TrackActivity self = this;
		data_pipe = new DataPipe<SerializedFact>(this, DATA_PORT);
		data_pipe.addDataReceivedListener(new DataReceivedListener<SerializedFact>() {
			@Override
			public void performDataReceivedAction(final List<SerializedFact> facts) {
				self.runOnUiThread(
						new Runnable() {
							@Override
							public void run() {
								self.receiveData(facts);
							}
						});
			}
		});
		data_pipe.setExceptionListener(new ExceptionListener() {
			@Override
			public void performExceptionAction(final Exception e) {
				self.postAlert("Error!", e.toString());
			}
		});
		data_pipe.initReceiver();
	}	
	
	public void receiveData(List<SerializedFact> facts) {
		// String msg = String.format("Received %s facts", facts.size());
		// Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
		rm.addExternalGoals(facts);
	}
	
	public void sendData(final String ip_address, final List<SerializedFact> facts) {
		// String msg = String.format("Sending %s facts to %s", facts.size(), ip_address);
		// Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();		
		data_pipe.sendData(facts, ip_address);
	}	
	
	public void postAlert(final String title, final String msg) {
		final TrackActivity self = this;
		runOnUiThread(new Runnable() {
			@Override
			public void run() {
				AlertDialog.Builder alert = new AlertDialog.Builder(self);
				alert.setTitle(title);
				alert.setMessage(msg);
				alert.setPositiveButton("Ok", new OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
					}
				});
				alert.show();
			}
		});
	}	
	
	public void postToast(final String msg) {
		final TrackActivity self = this;
		runOnUiThread(new Runnable() {
			@Override
			public void run() {
				Toast.makeText(self, msg, Toast.LENGTH_SHORT).show();
			}
		});
	}	
	
	// Car Methods
	public void addCar(int loc) {
		Car car = new Car(loc);
		cars.addLast(car);
		track_canvas.drawRect(car.getSprite(), car.getPaint());
	}
	
	public void addCar(int loc, boolean acc) {
		Car car = new Car(loc);
		car.toggle(acc);
		cars.addLast(car);
		track_canvas.drawRect(car.getSprite(), car.getPaint());
	}
	
	public void removeCar(int loc) {
		for (int x=0; x < cars.size(); x++) {
			Car car = cars.get(x);
			if (car.getOwner() == loc) {
		    	Paint bg_paint = new Paint();
		    	bg_paint.setColor(BG_COLOR);
		    	track_canvas.drawRect(car.getSprite(), bg_paint);
				cars.remove(x);
				return;
			}
		}
	}
	
	public void toggleCar(int loc, boolean acc) {
		for (Car car: cars) {
			if (loc == car.getOwner()) {
				// car.toggle(acc);
				if (acc) {
					car.impulse();
				}
				return;
			}
		}
	}
	
	public void countDown(final int count) {
		final TrackActivity self = this;
		runOnUiThread(new Runnable() {
			@Override
			public void run() {
				try {
					int cnt = count;
					while(cnt > 0) {
						Toast.makeText(self, String.format("Get Ready: %s" , cnt), Toast.LENGTH_SHORT).show();
						Thread.sleep(1000);
						cnt--;
					}
					Toast.makeText(self, "GO!!!", Toast.LENGTH_SHORT).show();
					self.setBrakes(false);
				} catch(InterruptedException e) {
					e.printStackTrace();	
				}
				
			}
		});
	}	
	
	public void setBrakes(boolean br) {
		brakes = br;
	}
	
	public boolean breaksOn() { return brakes; }
	
}
